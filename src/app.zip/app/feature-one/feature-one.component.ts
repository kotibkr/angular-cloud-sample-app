import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-one',
  templateUrl: './feature-one.component.html',
  styleUrls: ['./feature-one.component.scss']
})
export class FeatureOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
