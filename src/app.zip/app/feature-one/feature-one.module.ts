import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FeatureOneComponent } from './feature-one.component';
import { MatCardModule } from '@angular/material/card';

@NgModule({
  declarations: [FeatureOneComponent],
  imports: [CommonModule,
    MatCardModule
  ],
  providers: []
})
export class FeatureOneModule { }
