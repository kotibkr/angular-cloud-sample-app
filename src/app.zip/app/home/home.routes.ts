import { Routes } from '@angular/router';
import { HomeComponent } from './home.component';

export const HomeRoutes: Routes = [
    {
        path: '',
        component: HomeComponent,
        canActivate: [],
        redirectTo: ""
    },
    {
      path: 'app/home',
      loadChildren: () => import('./../../app/home/home.module').then(x => x.HomeModule)
    }
];
