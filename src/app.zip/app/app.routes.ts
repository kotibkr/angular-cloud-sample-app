import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { FeatureOneComponent } from './feature-one/feature-one.component';
import { FeatureTwoComponent } from './feature-two/feature-two.component';
import { WildcardPagenotfoundComponent } from './wildcard-pagenotfound/wildcard-pagenotfound.component';

export const AppRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'app/feature-one', component: FeatureOneComponent },
  { path: 'app/feature-two', component: FeatureTwoComponent },
  { path: '**', component: WildcardPagenotfoundComponent }
];
