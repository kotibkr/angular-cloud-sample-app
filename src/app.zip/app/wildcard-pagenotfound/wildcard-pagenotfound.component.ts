import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wildcard-pagenotfound',
  templateUrl: './wildcard-pagenotfound.component.html'
})
export class WildcardPagenotfoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
