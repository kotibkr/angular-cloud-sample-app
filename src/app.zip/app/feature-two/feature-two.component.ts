import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-two',
  templateUrl: './feature-two.component.html',
  styleUrls: ['./feature-two.component.scss']
})
export class FeatureTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
