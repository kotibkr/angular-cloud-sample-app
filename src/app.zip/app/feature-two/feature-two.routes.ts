import { Routes } from '@angular/router';
import { FeatureTwoComponent } from './feature-two.component';

export const FeatureTwoRoutes: Routes = [
  {
    path: '',
    component: FeatureTwoComponent
  }
];
